#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""py.test for co3"""

import os
import logging
import pytest
import mock

from requests import Response
from .co3 import SimpleHTTPException


logging.basicConfig(level=logging.DEBUG)


def test_SimpleHTTPException():

    # pytest.raises(SimpleHTTPException):

    response = mock.MagicMock(spec=Response)
    response.text.return_value = u"þšéûðö"
    response.reason = u"ļöçåļîžåţîöñ"
    SimpleHTTPException(response)
