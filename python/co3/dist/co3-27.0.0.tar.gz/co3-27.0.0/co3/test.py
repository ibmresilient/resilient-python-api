#!/usr/local/bin/python3
class D(type):
    def __new__(cls, name, bases, dct):
        print("cls is:   ", cls)
        print("name is:  ", name)
        print("bases is: ", bases)
        print("dct is:   ", dct)
        return super().__new__(cls, name, bases, dct)
    
    def __init__():
        print("stuff")
        
class E(object):
    __metaclass__ = D

class F(E): pass

class A(object):
    pass
